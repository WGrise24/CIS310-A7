--1
select	*
from	LGDepartment

--2
select	prod_sku, prod_descript, prod_type, prod_base,
		prod_category, prod_price
from	LGProduct
where	prod_base = 'Water' and prod_category = 'Sealer'

--3
select	emp_fname, emp_lname, emp_email
from	LGEmployee
where	emp_hiredate between '2001-01-01' and '2010-12-31'
order by emp_lname, emp_fname

--4
select	emp_fname, emp_lname, emp_phone, emp_title, dept_num
from	LGEmployee
where	dept_num = 300 or emp_title = 'CLERK I'
order by emp_lname, emp_fname

--5
select	e.emp_num, e.emp_lname, e.emp_fname, s.sal_from, 
		s.sal_end, s.sal_amount
from	LGEmployee e inner join LGSalary_History s 
on		e.emp_num = s.emp_num
where	e.emp_num  in (83731,83745,84039)
order by e.emp_num, s.sal_from

--6
select	distinct cust_fname, cust_lname, cust_street, cust_city, cust_state, cust_zip
from	LGCustomer c, LGInvoice i, LGLine l, LGProduct p, LGBrand b
where	c.cust_code = i.cust_code and i.inv_num = l.inv_num and l.prod_sku = p.prod_sku 
		and p.brand_id = b.brand_id and	brand_name = 'Foresters Best' 
		and prod_category = 'Top Coat' and inv_date between '2013-07-15' and '2013-07-31'
order by cust_state, cust_lname, cust_fname

--7
select	e.emp_num, e.emp_lname, e.emp_email, e.emp_title, d.dept_name
from	LGEmployee e inner join LGDepartment d
on		e.dept_num = d.dept_num
where	e.emp_title = 'Associate'
order by d.dept_name, e.emp_title

--8
select	b.brand_name, count(p.prod_sku) as num_products
from	LGBrand b inner join LGProduct p
on		b.brand_id = p.brand_id
group by b.brand_name
order by b.brand_name

--9
select	p.prod_category, count(p.prod_sku) as num_products
from	LGProduct p
where	p.prod_base = 'Water'
group by p.prod_category

--10
select	prod_base, prod_type, count(prod_sku) as num_products
from	LGProduct
group by prod_base, prod_type

--11
select	brand_id, sum(prod_qoh) as total_inventory
from	LGProduct
group by brand_id
order by brand_id desc

--12. 
select	p.brand_id, b.brand_name, cast(avg(p.prod_price) as Decimal(10,2)) as avg_price
from	LGProduct p inner join LGBrand b
on		p.brand_id = b.brand_id
group by p.brand_id, b.brand_name
order by b.brand_name

--13. 
select	dept_num, max(emp_hiredate) as newest_hire
from	LGEmployee
group by dept_num

--14.
select	e.emp_num, e.emp_fname, e.emp_lname, max(s.sal_amount) as largest_salary
from	LGEmployee e inner join LGSalary_History s
on		e.emp_num = s.emp_num
where	e.dept_num = 200
group by e.emp_num, e.emp_fname, e.emp_lname
order by largest_salary desc

--15.
select	i.cust_code, c.cust_fname, c.cust_lname, sum(i.inv_total) as total_inv
from	LGInvoice i inner join LGCustomer c
on		i.cust_code = c.cust_code
group by i.cust_code, c.cust_fname, c.cust_lname
having	sum(inv_total) > 1500
order by total_inv desc

--16.
select	distinct d.dept_num, d.dept_name, d.dept_phone, d.emp_num, e.emp_lname
from	LGDepartment d inner join LGEmployee e
on		d.emp_num = e.emp_num
group by d.dept_num, d.dept_name, d.dept_phone, d.emp_num, e.emp_lname
order by d.dept_name

--17
select distinct v.vend_id, v.vend_name, b.brand_name, count(p.prod_sku) as total_num_of_prod
from	LGVendor v inner join LGSupplies s on v.vend_id = s.vend_id 
		inner join LGProduct p on s.prod_sku = p.prod_sku 
		inner join LGBrand b on p.brand_id = b.brand_id
group by v.vend_id, v.vend_name, b.brand_name
order by v.vend_name, b.brand_name

--18
select	e.emp_num, e.emp_lname, e.emp_fname, sum(i.inv_total) as inv_total
from	LGEmployee e inner join LGInvoice i
on		e.emp_num = i.employee_id
group by e.emp_num, e.emp_lname, e.emp_fname
having	sum(i.inv_total) > 0
order by e.emp_lname, e.emp_fname

--19. 
select	Max(a.avg_price) as largest_avg
from	(select brand_id, round(avg(prod_price),2) as avg_price	
		 from LGProduct 
		 group by brand_id
		) a

--20
select	p.brand_id, b.brand_name, b.brand_type, round(avg(p.prod_price),2) as avg_price
from	LGProduct p, LGBrand b
where	p.brand_id = b.brand_id
group by p.brand_id, b.brand_name, b.brand_type
having	round(avg(p.prod_price),2) = (select	max(a.avg_price) as largest_avg
									from	(select	p.brand_id, 
											 round(avg(p.prod_price),2) as avg_price
											 from lgproduct p
											 group by p.brand_id) a)

--21
select	distinct e.emp_fname + ' ' + e.emp_lname as manager_name, d.dept_name, d.dept_phone, 
		e.emp_fname + ' ' + e.emp_lname as employee_name, 
		c.cust_fname + ' ' + c.cust_lname as customer_name, i.inv_date, i.inv_total
from	LGEmployee e, LGDepartment d, LGCustomer c, LGInvoice i
where	e.emp_num = d.emp_num and c.cust_code = i.cust_code and e.emp_num = i.employee_id
		and c.cust_lname = 'Hagan' and i.inv_date = '2013-05-18'
group by d.dept_name, d.dept_phone, i.inv_date, i.inv_total

select *
from LGINVOICE
177,222
select * from lginvoice where cust_code in (177,222) and inv_date = '2011-MAY-18'
select e.emp_fname + e.emp_lname as "Manager Name", d.dept_name from lgemployee e, lgdepartment d where e.emp_num = d.emp_num
